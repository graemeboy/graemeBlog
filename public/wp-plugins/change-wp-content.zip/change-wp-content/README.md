Change wp-content
=================

A Wordpress plugin that will rename the wp-content directory to "media", which might help to improve site security.
